package com.ratnashree.pharma

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class PartyActivity : AppCompatActivity() {
    private lateinit var db: PartyDbHelper
    private lateinit var search: EditText
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = PartyDbHelper(this)
        setContentView(R.layout.activity_party)
        search = findViewById(R.id.partySearch)
        list = findViewById(R.id.partyList)
        findViewById<Button>(R.id.addParty).setOnClickListener { showPartyForm(null) }
        search.addTextChangedListener(SimpleTextWatcher { refresh(it) })
        refresh("")
    }

    private fun refresh(q: String) {
        list.removeAllViews()
        val parties = db.search(q)
        if (parties.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No medicals found\nTap + ADD MEDICAL to create one."
                textSize = 16f
                gravity = Gravity.CENTER
                setPadding(20, 50, 20, 50)
            }
            list.addView(empty)
            return
        }
        parties.forEach { p ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(18, 14, 18, 14)
                background = getDrawable(android.R.drawable.dialog_holo_light_frame)
                setOnClickListener { showPartyForm(p) }
            }
            val name = TextView(this).apply { text = p.medicalName; textSize = 19f; setTypeface(typeface, android.graphics.Typeface.BOLD) }
            val sub = TextView(this).apply {
                val mobile = if (p.mobile.isBlank()) "" else " • ${p.mobile}"
                val state = if (p.state.isBlank()) "" else " • ${p.state}"
                text = "${p.ownerName.ifBlank { "Owner not set" }}$mobile$state"
                textSize = 14f
            }
            val balance = TextView(this).apply {
                text = "Credit Limit: ₹${money(p.creditLimit)}    Opening: ₹${money(p.openingBalance)}"
                textSize = 13f
            }
            card.addView(name); card.addView(sub); card.addView(balance)
            val lp = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 10) }
            list.addView(card, lp)
        }
    }

    private fun showPartyForm(existing: Party?) {
        val fields = mutableListOf<EditText>()
        fun field(hint: String, inputType: Int = InputType.TYPE_CLASS_TEXT): EditText = EditText(this).apply {
            this.hint = hint
            this.inputType = inputType
            setSingleLine(false)
            fields.add(this)
        }
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 4, 24, 0) }
        val name = field("Medical Name *")
        val owner = field("Owner / Contact Person")
        val mobile = field("Mobile", InputType.TYPE_CLASS_PHONE)
        val address = field("Address")
        val gstin = field("GSTIN")
        val state = field("State")
        val stateCode = field("GST State Code", InputType.TYPE_CLASS_NUMBER)
        val dl1 = field("Drug Licence No. 1")
        val dl2 = field("Drug Licence No. 2")
        val credit = field("Credit Limit", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val opening = field("Opening Balance", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        listOf(name, owner, mobile, address, gstin, state, stateCode, dl1, dl2, credit, opening).forEach { container.addView(it) }

        existing?.let {
            name.setText(it.medicalName); owner.setText(it.ownerName); mobile.setText(it.mobile); address.setText(it.address)
            gstin.setText(it.gstin); state.setText(it.state); stateCode.setText(it.stateCode); dl1.setText(it.drugLicense1); dl2.setText(it.drugLicense2)
            credit.setText(it.creditLimit.toString()); opening.setText(it.openingBalance.toString())
        }

        val dialog = AlertDialog.Builder(this).setTitle(if (existing == null) "Add Medical / Party" else "Edit Medical / Party")
            .setView(container)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("SAVE", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val medical = name.text.toString().trim()
                if (medical.isBlank()) { name.error = "Medical Name is required"; return@setOnClickListener }
                val party = Party(
                    id = existing?.id ?: 0L, medicalName = medical, ownerName = owner.text.toString(), mobile = mobile.text.toString(),
                    address = address.text.toString(), gstin = gstin.text.toString(), state = state.text.toString(), stateCode = stateCode.text.toString(),
                    drugLicense1 = dl1.text.toString(), drugLicense2 = dl2.text.toString(),
                    creditLimit = credit.text.toString().toDoubleOrNull() ?: 0.0,
                    openingBalance = opening.text.toString().toDoubleOrNull() ?: 0.0
                )
                db.save(party); dialog.dismiss(); refresh(search.text.toString())
                Toast.makeText(this, "Medical saved", Toast.LENGTH_SHORT).show()
            }
        }
        if (existing != null) {
            dialog.setOnShowListener { d ->
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener { dialog.dismiss() }
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val medical = name.text.toString().trim()
                    if (medical.isBlank()) { name.error = "Medical Name is required"; return@setOnClickListener }
                    db.save(Party(existing.id, medicalName=medical, ownerName=owner.text.toString(), mobile=mobile.text.toString(), address=address.text.toString(), gstin=gstin.text.toString(), state=state.text.toString(), stateCode=stateCode.text.toString(), drugLicense1=dl1.text.toString(), drugLicense2=dl2.text.toString(), creditLimit=credit.text.toString().toDoubleOrNull() ?: 0.0, openingBalance=opening.text.toString().toDoubleOrNull() ?: 0.0))
                    dialog.dismiss(); refresh(search.text.toString()); Toast.makeText(this, "Medical updated", Toast.LENGTH_SHORT).show()
                }
                val delete = Button(this).apply { text = "DEACTIVATE" }
                container.addView(delete)
                delete.setOnClickListener {
                    AlertDialog.Builder(this).setTitle("Deactivate medical?").setMessage(existing.medicalName).setNegativeButton("CANCEL", null).setPositiveButton("DEACTIVATE") { _, _ -> db.deactivate(existing.id); dialog.dismiss(); refresh(search.text.toString()) }.show()
                }
            }
        }
        dialog.show()
    }

    private fun money(v: Double) = String.format("%.2f", v)
}

class SimpleTextWatcher(private val onChange: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { onChange(s?.toString() ?: "") }
    override fun afterTextChanged(s: android.text.Editable?) = Unit
}
