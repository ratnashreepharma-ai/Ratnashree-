package com.ratnashree.pharma
import android.os.Bundle
import android.widget.Toast
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity: AppCompatActivity() {
 override fun onCreate(b: Bundle?) {
  super.onCreate(b); setContentView(R.layout.activity_main)
  findViewById<android.view.View>(R.id.btnParty).setOnClickListener { startActivity(Intent(this, PartyActivity::class.java)) }
  findViewById<android.view.View>(R.id.btnProduct).setOnClickListener { startActivity(Intent(this, ProductActivity::class.java)) }
  findViewById<android.view.View>(R.id.btnSale).setOnClickListener { saleDialog() }
  findViewById<android.view.View>(R.id.btnImport).setOnClickListener { Toast.makeText(this,"Vyapar migration module will use the recovered .vyb database mapping.",Toast.LENGTH_LONG).show() }
 }
 private fun partyDialog() = MaterialAlertDialogBuilder(this).setTitle("Medical / Party Master")
  .setMessage("Fields locked into the design:\n\nMedical Name\nOwner / Contact\nMobile\nAddress\nGSTIN\nState + GST State Code\nDrug Licence No. 1\nDrug Licence No. 2\nCredit Limit / Opening Balance")
  .setPositiveButton("OK",null).show()
 private fun productDialog() = MaterialAlertDialogBuilder(this).setTitle("Product Master")
  .setMessage("Product, Company, Unit, HSN, Batch/Expiry support, purchase rate, sale rate and product-wise GST (0/5/12/18/28%).")
  .setPositiveButton("OK",null).show()
 private fun saleDialog() = MaterialAlertDialogBuilder(this).setTitle("New Sale Bill")
  .setMessage("Professional A5 Landscape invoice.\n\nBill-wise GST ON/OFF + product-wise GST.\nCGST/SGST or IGST using State Code.\nBatch, Expiry, Qty, Rate, Discount, Total.\n\nFooter reserved for RATNASHREE PHARMA authorized signature.")
  .setPositiveButton("OK",null).show()
}