package com.ratnashree.pharma

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ProductActivity : AppCompatActivity() {
    private lateinit var db: PartyDbHelper
    private lateinit var search: EditText
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = PartyDbHelper(this)
        setContentView(R.layout.activity_product)
        search = findViewById(R.id.productSearch)
        list = findViewById(R.id.productList)
        findViewById<Button>(R.id.addProduct).setOnClickListener { showProductForm(null) }
        search.addTextChangedListener(SimpleTextWatcher { refresh(it) })
        refresh("")
    }

    private fun refresh(q: String) {
        list.removeAllViews()
        val products = db.searchProducts(q)
        if (products.isEmpty()) {
            list.addView(TextView(this).apply { text="No products found\nTap + ADD PRODUCT to create one."; textSize=16f; gravity=Gravity.CENTER; setPadding(20,50,20,50) })
            return
        }
        products.forEach { p ->
            val card = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,14,18,14); background=getDrawable(android.R.drawable.dialog_holo_light_frame); setOnClickListener { showProductForm(p) } }
            card.addView(TextView(this).apply { text=p.productName; textSize=18f; setTypeface(typeface, android.graphics.Typeface.BOLD) })
            card.addView(TextView(this).apply { text="${p.company.ifBlank { "Company not set" }} • ${p.pack.ifBlank { "Pack not set" }}"; textSize=14f })
            card.addView(TextView(this).apply { text="GST ${money(p.gstPercent)}% • Purchase ₹${money(p.purchaseRate)} • Sale ₹${money(p.saleRate)} • MRP ₹${money(p.mrp)}"; textSize=13f })
            card.addView(TextView(this).apply { text="Batch: ${p.batch.ifBlank { "—" }} • Expiry: ${p.expiry.ifBlank { "—" }} • Stock: ${money(p.openingStock)}"; textSize=13f })
            list.addView(card, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,0,0,10) })
        }
    }

    private fun showProductForm(existing: Product?) {
        fun field(container: LinearLayout, hint: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText = EditText(this).apply { this.hint=hint; inputType=type; setSingleLine(true); container.addView(this) }
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,4,24,0) }
        val name=field(box,"Product Name *"); val company=field(box,"Company"); val pack=field(box,"Pack / Unit"); val hsn=field(box,"HSN")
        val gst=field(box,"GST % (0 / 5 / 12 / 18 / 28)",InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val purchase=field(box,"Purchase Rate",InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val sale=field(box,"Sale Rate",InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val mrp=field(box,"MRP",InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val batch=field(box,"Batch"); val expiry=field(box,"Expiry (MM/YYYY)"); val scheme=field(box,"Scheme");
        val discount=field(box,"Discount %",InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val stock=field(box,"Opening Stock",InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        existing?.let { name.setText(it.productName); company.setText(it.company); pack.setText(it.pack); hsn.setText(it.hsn); gst.setText(it.gstPercent.toString()); purchase.setText(it.purchaseRate.toString()); sale.setText(it.saleRate.toString()); mrp.setText(it.mrp.toString()); batch.setText(it.batch); expiry.setText(it.expiry); scheme.setText(it.scheme); discount.setText(it.discountPercent.toString()); stock.setText(it.openingStock.toString()) }
        val dialog=AlertDialog.Builder(this).setTitle(if(existing==null)"Add Product" else "Edit Product").setView(box).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n=name.text.toString().trim(); if(n.isBlank()){name.error="Product Name is required";return@setOnClickListener}
                val g=gst.text.toString().toDoubleOrNull() ?: 0.0; if(g !in 0.0..100.0){gst.error="Enter valid GST %";return@setOnClickListener}
                db.saveProduct(Product(existing?.id ?: 0L, productName=n, company=company.text.toString(), pack=pack.text.toString(), hsn=hsn.text.toString(), gstPercent=g, purchaseRate=purchase.text.toString().toDoubleOrNull()?:0.0, saleRate=sale.text.toString().toDoubleOrNull()?:0.0, mrp=mrp.text.toString().toDoubleOrNull()?:0.0, batch=batch.text.toString(), expiry=expiry.text.toString(), scheme=scheme.text.toString(), discountPercent=discount.text.toString().toDoubleOrNull()?:0.0, openingStock=stock.text.toString().toDoubleOrNull()?:0.0))
                dialog.dismiss(); refresh(search.text.toString()); Toast.makeText(this,if(existing==null)"Product saved" else "Product updated",Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
        if(existing!=null){
            val deactivate=Button(this).apply{text="DEACTIVATE";setOnClickListener{AlertDialog.Builder(this@ProductActivity).setTitle("Deactivate product?").setMessage(existing.productName).setNegativeButton("CANCEL",null).setPositiveButton("DEACTIVATE"){_,_->db.deactivateProduct(existing.id);dialog.dismiss();refresh(search.text.toString())}.show()}}
            box.addView(deactivate); dialog.window?.decorView?.post { }
        }
    }
    private fun money(v:Double)=String.format("%.2f",v)
}
