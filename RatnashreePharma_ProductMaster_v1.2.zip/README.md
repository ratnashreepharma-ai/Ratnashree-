# Ratnashree Pharma Android App

Version 1.1 — Medical / Party Master functional module.

## Party Master
- Add Medical / Party
- Search by medical name, owner/contact, or mobile
- Edit existing records
- Deactivate records (soft delete)
- Fields: Medical Name, Owner/Contact, Mobile, Address, GSTIN, State, GST State Code, Drug Licence 1 & 2, Credit Limit, Opening Balance
- Local SQLite storage with firm_id separation ready for multi-firm expansion

The project is intended to be built through GitHub Actions using the workflow in `.github/workflows/android-build.yml`.
