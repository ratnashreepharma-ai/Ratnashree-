# Ratnashree Pharma v1.4
Sale Bill update: Party/Product automatic loading, multiple bill items, product rate/GST/batch/expiry auto-fill, stock deduction, bill totals and A5 Landscape PDF generation.

GitHub Actions can build the debug APK using the existing workflow.
