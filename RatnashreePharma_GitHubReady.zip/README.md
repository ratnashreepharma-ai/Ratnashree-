# Ratnashree Pharma — GitHub APK Build

हा Android Studio शिवाय GitHub Actions मधून APK build करण्यासाठी तयार केलेला project आहे.

## मोबाईलवरून APK बनवण्याची पद्धत

1. GitHub वर `RatnashreePharma` नावाचे नवीन repository तयार करा.
2. या ZIP मधील सर्व files repository मध्ये upload करा.
3. `Commit changes` करा.
4. GitHub मधील **Actions** tab उघडा.
5. `Build Ratnashree Pharma APK` workflow निवडा.
6. `Run workflow` दाबा.
7. Build पूर्ण झाल्यावर workflow run उघडा.
8. **Artifacts** मध्ये `RatnashreePharma-debug-APK` डाउनलोड करा.
9. त्यातील `app-debug.apk` फोनमध्ये install करा.

## सध्याच्या app मध्ये
- Medical / Party Master shell
- Product Master shell
- New Sale Bill shell
- Vyapar migration entry point
- Multi-firm/database design foundation
- GitHub Actions APK build

पुढील development मध्ये Sale, Purchase, Stock, Payments, Reports, PDF Bill/Statement आणि Vyapar incremental import modules जोडता येतील.
