package com.ratnashree.pharma

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class PartyDbHelper(context: Context) : SQLiteOpenHelper(context, "ratnashree_pharma.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE parties (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                firm_id INTEGER NOT NULL DEFAULT 1,
                medical_name TEXT NOT NULL,
                owner_name TEXT,
                mobile TEXT,
                address TEXT,
                gstin TEXT,
                state TEXT,
                state_code TEXT,
                drug_license_1 TEXT,
                drug_license_2 TEXT,
                credit_limit REAL NOT NULL DEFAULT 0,
                opening_balance REAL NOT NULL DEFAULT 0,
                active INTEGER NOT NULL DEFAULT 1,
                created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX idx_parties_firm_name ON parties(firm_id, medical_name)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Reserved for future schema migrations.
    }

    fun search(query: String, firmId: Long = 1L): List<Party> {
        val result = mutableListOf<Party>()
        val db = readableDatabase
        val q = "%${query.trim()}%"
        val cursor = db.query(
            "parties", null,
            "firm_id=? AND active=1 AND (medical_name LIKE ? OR owner_name LIKE ? OR mobile LIKE ?)",
            arrayOf(firmId.toString(), q, q, q), null, null, "medical_name COLLATE NOCASE ASC"
        )
        cursor.use { c ->
            while (c.moveToNext()) result.add(fromCursor(c))
        }
        return result
    }

    fun get(id: Long): Party? {
        readableDatabase.query("parties", null, "id=?", arrayOf(id.toString()), null, null, null).use { c ->
            return if (c.moveToFirst()) fromCursor(c) else null
        }
    }

    fun save(p: Party): Long {
        val values = values(p)
        return if (p.id == 0L) writableDatabase.insertOrThrow("parties", null, values)
        else {
            writableDatabase.update("parties", values, "id=?", arrayOf(p.id.toString()))
            p.id
        }
    }

    fun deactivate(id: Long) {
        val values = ContentValues().apply { put("active", 0) }
        writableDatabase.update("parties", values, "id=?", arrayOf(id.toString()))
    }

    private fun values(p: Party) = ContentValues().apply {
        put("firm_id", p.firmId)
        put("medical_name", p.medicalName.trim())
        put("owner_name", p.ownerName.trim())
        put("mobile", p.mobile.trim())
        put("address", p.address.trim())
        put("gstin", p.gstin.trim().uppercase())
        put("state", p.state.trim())
        put("state_code", p.stateCode.trim())
        put("drug_license_1", p.drugLicense1.trim())
        put("drug_license_2", p.drugLicense2.trim())
        put("credit_limit", p.creditLimit)
        put("opening_balance", p.openingBalance)
        put("active", 1)
    }

    private fun fromCursor(c: android.database.Cursor) = Party(
        id = c.getLong(c.getColumnIndexOrThrow("id")),
        firmId = c.getLong(c.getColumnIndexOrThrow("firm_id")),
        medicalName = c.getString(c.getColumnIndexOrThrow("medical_name")) ?: "",
        ownerName = c.getString(c.getColumnIndexOrThrow("owner_name")) ?: "",
        mobile = c.getString(c.getColumnIndexOrThrow("mobile")) ?: "",
        address = c.getString(c.getColumnIndexOrThrow("address")) ?: "",
        gstin = c.getString(c.getColumnIndexOrThrow("gstin")) ?: "",
        state = c.getString(c.getColumnIndexOrThrow("state")) ?: "",
        stateCode = c.getString(c.getColumnIndexOrThrow("state_code")) ?: "",
        drugLicense1 = c.getString(c.getColumnIndexOrThrow("drug_license_1")) ?: "",
        drugLicense2 = c.getString(c.getColumnIndexOrThrow("drug_license_2")) ?: "",
        creditLimit = c.getDouble(c.getColumnIndexOrThrow("credit_limit")),
        openingBalance = c.getDouble(c.getColumnIndexOrThrow("opening_balance"))
    )
}

data class Party(
    val id: Long = 0L,
    val firmId: Long = 1L,
    val medicalName: String,
    val ownerName: String = "",
    val mobile: String = "",
    val address: String = "",
    val gstin: String = "",
    val state: String = "",
    val stateCode: String = "",
    val drugLicense1: String = "",
    val drugLicense2: String = "",
    val creditLimit: Double = 0.0,
    val openingBalance: Double = 0.0
)
