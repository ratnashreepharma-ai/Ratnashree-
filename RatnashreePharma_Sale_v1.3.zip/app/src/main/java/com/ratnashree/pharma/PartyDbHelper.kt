package com.ratnashree.pharma

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class PartyDbHelper(context: Context) : SQLiteOpenHelper(context, "ratnashree_pharma.db", null, 3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE parties (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                firm_id INTEGER NOT NULL DEFAULT 1,
                medical_name TEXT NOT NULL,
                owner_name TEXT,
                mobile TEXT,
                address TEXT,
                gstin TEXT,
                state TEXT,
                state_code TEXT,
                drug_license_1 TEXT,
                drug_license_2 TEXT,
                credit_limit REAL NOT NULL DEFAULT 0,
                opening_balance REAL NOT NULL DEFAULT 0,
                active INTEGER NOT NULL DEFAULT 1,
                created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX idx_parties_firm_name ON parties(firm_id, medical_name)")
        createProducts(db)
        createSales(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) createProducts(db)
        if (oldVersion < 3) createSales(db)
    }

    private fun createProducts(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                firm_id INTEGER NOT NULL DEFAULT 1,
                product_name TEXT NOT NULL,
                company TEXT,
                pack TEXT,
                hsn TEXT,
                gst_percent REAL NOT NULL DEFAULT 0,
                purchase_rate REAL NOT NULL DEFAULT 0,
                sale_rate REAL NOT NULL DEFAULT 0,
                mrp REAL NOT NULL DEFAULT 0,
                batch TEXT,
                expiry TEXT,
                scheme TEXT,
                discount_percent REAL NOT NULL DEFAULT 0,
                opening_stock REAL NOT NULL DEFAULT 0,
                active INTEGER NOT NULL DEFAULT 1,
                created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_products_firm_name ON products(firm_id, product_name)")
    }


    private fun createSales(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS sales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                firm_id INTEGER NOT NULL DEFAULT 1,
                invoice_no TEXT NOT NULL,
                invoice_date TEXT NOT NULL,
                party_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                batch TEXT,
                expiry TEXT,
                qty REAL NOT NULL,
                rate REAL NOT NULL,
                discount_percent REAL NOT NULL DEFAULT 0,
                gst_enabled INTEGER NOT NULL DEFAULT 1,
                gst_percent REAL NOT NULL DEFAULT 0,
                taxable_amount REAL NOT NULL DEFAULT 0,
                gst_amount REAL NOT NULL DEFAULT 0,
                total_amount REAL NOT NULL DEFAULT 0
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sales_firm_date ON sales(firm_id, invoice_date)")
    }

    fun allParties(firmId: Long = 1L): List<Party> = search("", firmId)

    fun allProducts(firmId: Long = 1L): List<Product> = searchProducts("", firmId)

    fun saveSale(invoiceNo: String, invoiceDate: String, partyId: Long, productId: Long, batch: String, expiry: String, qty: Double, rate: Double, discountPercent: Double, gstEnabled: Boolean, gstPercent: Double, taxable: Double, gstAmount: Double, total: Double, firmId: Long = 1L): Long {
        val v = ContentValues().apply {
            put("firm_id", firmId); put("invoice_no", invoiceNo); put("invoice_date", invoiceDate); put("party_id", partyId); put("product_id", productId)
            put("batch", batch); put("expiry", expiry); put("qty", qty); put("rate", rate); put("discount_percent", discountPercent)
            put("gst_enabled", if (gstEnabled) 1 else 0); put("gst_percent", gstPercent); put("taxable_amount", taxable); put("gst_amount", gstAmount); put("total_amount", total)
        }
        return writableDatabase.insertOrThrow("sales", null, v)
    }

    fun searchProducts(query: String, firmId: Long = 1L): List<Product> {
        val result = mutableListOf<Product>()
        val q = "%${query.trim()}%"
        readableDatabase.query("products", null,
            "firm_id=? AND active=1 AND (product_name LIKE ? OR company LIKE ? OR hsn LIKE ? OR batch LIKE ?)",
            arrayOf(firmId.toString(), q, q, q, q), null, null, "product_name COLLATE NOCASE ASC").use { c ->
            while (c.moveToNext()) result.add(productFromCursor(c))
        }
        return result
    }

    fun saveProduct(p: Product): Long {
        val values = ContentValues().apply {
            put("firm_id", p.firmId); put("product_name", p.productName.trim()); put("company", p.company.trim());
            put("pack", p.pack.trim()); put("hsn", p.hsn.trim()); put("gst_percent", p.gstPercent);
            put("purchase_rate", p.purchaseRate); put("sale_rate", p.saleRate); put("mrp", p.mrp);
            put("batch", p.batch.trim()); put("expiry", p.expiry.trim()); put("scheme", p.scheme.trim());
            put("discount_percent", p.discountPercent); put("opening_stock", p.openingStock); put("active", 1)
        }
        return if (p.id == 0L) writableDatabase.insertOrThrow("products", null, values)
        else { writableDatabase.update("products", values, "id=?", arrayOf(p.id.toString())); p.id }
    }

    fun deactivateProduct(id: Long) {
        writableDatabase.update("products", ContentValues().apply { put("active", 0) }, "id=?", arrayOf(id.toString()))
    }

    private fun productFromCursor(c: android.database.Cursor) = Product(
        id=c.getLong(c.getColumnIndexOrThrow("id")), firmId=c.getLong(c.getColumnIndexOrThrow("firm_id")),
        productName=c.getString(c.getColumnIndexOrThrow("product_name")) ?: "", company=c.getString(c.getColumnIndexOrThrow("company")) ?: "",
        pack=c.getString(c.getColumnIndexOrThrow("pack")) ?: "", hsn=c.getString(c.getColumnIndexOrThrow("hsn")) ?: "",
        gstPercent=c.getDouble(c.getColumnIndexOrThrow("gst_percent")), purchaseRate=c.getDouble(c.getColumnIndexOrThrow("purchase_rate")),
        saleRate=c.getDouble(c.getColumnIndexOrThrow("sale_rate")), mrp=c.getDouble(c.getColumnIndexOrThrow("mrp")),
        batch=c.getString(c.getColumnIndexOrThrow("batch")) ?: "", expiry=c.getString(c.getColumnIndexOrThrow("expiry")) ?: "",
        scheme=c.getString(c.getColumnIndexOrThrow("scheme")) ?: "", discountPercent=c.getDouble(c.getColumnIndexOrThrow("discount_percent")),
        openingStock=c.getDouble(c.getColumnIndexOrThrow("opening_stock"))
    )

    fun search(query: String, firmId: Long = 1L): List<Party> {
        val result = mutableListOf<Party>()
        val db = readableDatabase
        val q = "%${query.trim()}%"
        val cursor = db.query(
            "parties", null,
            "firm_id=? AND active=1 AND (medical_name LIKE ? OR owner_name LIKE ? OR mobile LIKE ?)",
            arrayOf(firmId.toString(), q, q, q), null, null, "medical_name COLLATE NOCASE ASC"
        )
        cursor.use { c ->
            while (c.moveToNext()) result.add(fromCursor(c))
        }
        return result
    }

    fun get(id: Long): Party? {
        readableDatabase.query("parties", null, "id=?", arrayOf(id.toString()), null, null, null).use { c ->
            return if (c.moveToFirst()) fromCursor(c) else null
        }
    }

    fun save(p: Party): Long {
        val values = values(p)
        return if (p.id == 0L) writableDatabase.insertOrThrow("parties", null, values)
        else {
            writableDatabase.update("parties", values, "id=?", arrayOf(p.id.toString()))
            p.id
        }
    }

    fun deactivate(id: Long) {
        val values = ContentValues().apply { put("active", 0) }
        writableDatabase.update("parties", values, "id=?", arrayOf(id.toString()))
    }

    private fun values(p: Party) = ContentValues().apply {
        put("firm_id", p.firmId)
        put("medical_name", p.medicalName.trim())
        put("owner_name", p.ownerName.trim())
        put("mobile", p.mobile.trim())
        put("address", p.address.trim())
        put("gstin", p.gstin.trim().uppercase())
        put("state", p.state.trim())
        put("state_code", p.stateCode.trim())
        put("drug_license_1", p.drugLicense1.trim())
        put("drug_license_2", p.drugLicense2.trim())
        put("credit_limit", p.creditLimit)
        put("opening_balance", p.openingBalance)
        put("active", 1)
    }

    private fun fromCursor(c: android.database.Cursor) = Party(
        id = c.getLong(c.getColumnIndexOrThrow("id")),
        firmId = c.getLong(c.getColumnIndexOrThrow("firm_id")),
        medicalName = c.getString(c.getColumnIndexOrThrow("medical_name")) ?: "",
        ownerName = c.getString(c.getColumnIndexOrThrow("owner_name")) ?: "",
        mobile = c.getString(c.getColumnIndexOrThrow("mobile")) ?: "",
        address = c.getString(c.getColumnIndexOrThrow("address")) ?: "",
        gstin = c.getString(c.getColumnIndexOrThrow("gstin")) ?: "",
        state = c.getString(c.getColumnIndexOrThrow("state")) ?: "",
        stateCode = c.getString(c.getColumnIndexOrThrow("state_code")) ?: "",
        drugLicense1 = c.getString(c.getColumnIndexOrThrow("drug_license_1")) ?: "",
        drugLicense2 = c.getString(c.getColumnIndexOrThrow("drug_license_2")) ?: "",
        creditLimit = c.getDouble(c.getColumnIndexOrThrow("credit_limit")),
        openingBalance = c.getDouble(c.getColumnIndexOrThrow("opening_balance"))
    )
}

data class Party(
    val id: Long = 0L,
    val firmId: Long = 1L,
    val medicalName: String,
    val ownerName: String = "",
    val mobile: String = "",
    val address: String = "",
    val gstin: String = "",
    val state: String = "",
    val stateCode: String = "",
    val drugLicense1: String = "",
    val drugLicense2: String = "",
    val creditLimit: Double = 0.0,
    val openingBalance: Double = 0.0
)


data class Product(
    val id: Long = 0L, val firmId: Long = 1L, val productName: String, val company: String = "", val pack: String = "",
    val hsn: String = "", val gstPercent: Double = 0.0, val purchaseRate: Double = 0.0, val saleRate: Double = 0.0,
    val mrp: Double = 0.0, val batch: String = "", val expiry: String = "", val scheme: String = "",
    val discountPercent: Double = 0.0, val openingStock: Double = 0.0
)
