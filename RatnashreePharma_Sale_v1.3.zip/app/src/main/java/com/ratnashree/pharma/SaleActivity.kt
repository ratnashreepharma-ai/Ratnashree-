package com.ratnashree.pharma

import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.round

class SaleActivity : AppCompatActivity() {
    private lateinit var db: PartyDbHelper
    private lateinit var partySpinner: Spinner
    private lateinit var productSpinner: Spinner
    private lateinit var qty: EditText
    private lateinit var rate: EditText
    private lateinit var discount: EditText
    private lateinit var gstSwitch: Switch
    private lateinit var totalView: TextView
    private lateinit var gstView: TextView
    private var parties = listOf<Party>()
    private var products = listOf<Product>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = PartyDbHelper(this)
        setContentView(R.layout.activity_sale)
        partySpinner = findViewById(R.id.partySpinner)
        productSpinner = findViewById(R.id.productSpinner)
        qty = findViewById(R.id.saleQty); rate = findViewById(R.id.saleRate); discount = findViewById(R.id.saleDiscount)
        gstSwitch = findViewById(R.id.gstSwitch); totalView = findViewById(R.id.saleTotal); gstView = findViewById(R.id.saleGst)
        loadMasters()
        productSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { if (products.isNotEmpty()) { rate.setText(products[position].saleRate.toString()); recalc() } }
        }
        listOf(qty, rate, discount).forEach { it.setOnFocusChangeListener { _, _ -> recalc() } }
        gstSwitch.setOnCheckedChangeListener { _, _ -> recalc() }
        findViewById<Button>(R.id.saveSale).setOnClickListener { save() }
        recalc()
    }

    private fun loadMasters() {
        parties = db.allParties()
        products = db.allProducts()
        partySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, parties.map { it.medicalName })
        productSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, products.map { "${it.productName} • ${it.batch.ifBlank { "No batch" }}" })
        if (parties.isEmpty()) Toast.makeText(this, "Add a Medical first", Toast.LENGTH_LONG).show()
        if (products.isEmpty()) Toast.makeText(this, "Add a Product first", Toast.LENGTH_LONG).show()
    }

    private fun recalc() {
        val q = qty.text.toString().toDoubleOrNull() ?: 0.0
        val r = rate.text.toString().toDoubleOrNull() ?: 0.0
        val d = discount.text.toString().toDoubleOrNull() ?: 0.0
        val p = products.getOrNull(productSpinner.selectedItemPosition)
        val gst = if (gstSwitch.isChecked) (p?.gstPercent ?: 0.0) else 0.0
        val gross = q * r
        val disc = gross * d / 100.0
        val taxable = gross - disc
        val gstAmt = taxable * gst / 100.0
        val total = taxable + gstAmt
        gstView.text = "GST: ₹${money(gstAmt)} (${money(gst)}%)"
        totalView.text = "Grand Total: ₹${money(total)}"
    }

    private fun save() {
        val party = parties.getOrNull(partySpinner.selectedItemPosition)
        val product = products.getOrNull(productSpinner.selectedItemPosition)
        if (party == null || product == null) { Toast.makeText(this, "Select Medical and Product", Toast.LENGTH_SHORT).show(); return }
        val q = qty.text.toString().toDoubleOrNull() ?: 0.0
        val r = rate.text.toString().toDoubleOrNull() ?: 0.0
        if (q <= 0 || r < 0) { Toast.makeText(this, "Enter valid Qty and Rate", Toast.LENGTH_SHORT).show(); return }
        val d = discount.text.toString().toDoubleOrNull() ?: 0.0
        val gst = if (gstSwitch.isChecked) product.gstPercent else 0.0
        val gross = q * r; val discAmt = gross * d / 100.0; val taxable = gross - discAmt; val gstAmt = taxable * gst / 100.0; val total = taxable + gstAmt
        val invoice = "RP-${SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())}"
        db.saveSale(invoice, SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date()), party.id, product.id, product.batch, product.expiry, q, r, d, gstSwitch.isChecked, gst, round2(taxable), round2(gstAmt), round2(total))
        Toast.makeText(this, "Sale saved • $invoice • ₹${money(total)}", Toast.LENGTH_LONG).show()
        qty.setText("1"); discount.setText("0"); recalc()
    }

    private fun round2(v: Double) = round(v * 100.0) / 100.0
    private fun money(v: Double) = String.format(Locale.US, "%.2f", v)
}
