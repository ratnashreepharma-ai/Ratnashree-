package com.ratnashree.pharma

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

class VyaparImportActivity : AppCompatActivity() {
    private val pickCode = 7001
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_import)
        status = findViewById(R.id.txtImportStatus)
        findViewById<Button>(R.id.btnPickVyapar).setOnClickListener { pickFile() }
        findViewById<Button>(R.id.btnCloseImport).setOnClickListener { finish() }
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i, pickCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickCode || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        try {
            status.text = "Reading Vyapar backup..."
            val local = File(cacheDir, "vyapar_import_${System.currentTimeMillis()}")
            contentResolver.openInputStream(uri).use { input -> FileOutputStream(local).use { output -> input!!.copyTo(output) } }
            val dbFile = if (local.extension.equals("vyb", true) || local.name.lowercase().contains("vypar")) extractVyp(local) else local
            val result = PartyDbHelper(this).importVyaparData(dbFile.absolutePath)
            status.text = "Import complete\nNew Parties: ${result.first}\nNew Products: ${result.second}\nExisting records were updated, not duplicated."
            Toast.makeText(this, "Vyapar import completed", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            status.text = "Import failed: ${e.message ?: "Unknown error"}"
        }
    }

    private fun extractVyp(file: File): File {
        val outDir = File(cacheDir, "vyapar_extract").apply { mkdirs() }
        ZipInputStream(file.inputStream().buffered()).use { zis ->
            while (true) {
                val entry = zis.nextEntry ?: break
                if (!entry.isDirectory && entry.name.lowercase().endsWith(".vyp")) {
                    val out = File(outDir, "source.vyp")
                    FileOutputStream(out).use { zis.copyTo(it) }
                    return out
                }
            }
        }
        throw IllegalArgumentException(".vyp database not found inside this backup")
    }
}
