package com.ratnashree.pharma

import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.round

data class SaleLine(val product: Product, val qty: Double, val rate: Double, val discount: Double, val gstEnabled: Boolean) {
    val gross get() = qty * rate
    val discountAmount get() = gross * discount / 100.0
    val taxable get() = gross - discountAmount
    val gstPercent get() = if (gstEnabled) product.gstPercent else 0.0
    val gstAmount get() = taxable * gstPercent / 100.0
    val total get() = taxable + gstAmount
}

class SaleActivity : AppCompatActivity() {
    private lateinit var db: PartyDbHelper
    private lateinit var partySpinner: Spinner
    private lateinit var productSpinner: Spinner
    private lateinit var qty: EditText
    private lateinit var rate: EditText
    private lateinit var discount: EditText
    private lateinit var gstSwitch: Switch
    private lateinit var totalView: TextView
    private lateinit var gstView: TextView
    private lateinit var itemsContainer: LinearLayout
    private lateinit var partyInfo: TextView
    private lateinit var productInfo: TextView
    private var parties = listOf<Party>()
    private var products = listOf<Product>()
    private val lines = mutableListOf<SaleLine>()
    private val invoiceNo = "RP-${SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())}"
    private val invoiceDate = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = PartyDbHelper(this)
        setContentView(R.layout.activity_sale)
        partySpinner = findViewById(R.id.partySpinner); productSpinner = findViewById(R.id.productSpinner)
        qty = findViewById(R.id.saleQty); rate = findViewById(R.id.saleRate); discount = findViewById(R.id.saleDiscount)
        gstSwitch = findViewById(R.id.gstSwitch); totalView = findViewById(R.id.saleTotal); gstView = findViewById(R.id.saleGst)
        itemsContainer = findViewById(R.id.itemsContainer); partyInfo = findViewById(R.id.partyInfo); productInfo = findViewById(R.id.productInfo)
        findViewById<TextView>(R.id.invoiceInfo).text = "Invoice No: $invoiceNo   •   Date: $invoiceDate"
        loadMasters()
        partySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val p = parties.getOrNull(position)
                partyInfo.text = if (p == null) "No Medical added. Add one in Party Master." else "${p.ownerName.ifBlank { "Owner not set" }} • ${p.mobile.ifBlank { "Mobile not set" }}\nGSTIN: ${p.gstin.ifBlank { "Not set" }} • State Code: ${p.stateCode.ifBlank { "Not set" }}"
            }
        }
        productSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                products.getOrNull(position)?.let { p ->
                    rate.setText(if (p.saleRate > 0) money(p.saleRate) else "")
                    discount.setText(money(p.discountPercent))
                    productInfo.text = "Batch: ${p.batch.ifBlank { "-" }} • Exp: ${p.expiry.ifBlank { "-" }} • GST: ${money(p.gstPercent)}% • Stock: ${money(p.openingStock)}"
                    recalc()
                }
            }
        }
        listOf(qty, rate, discount).forEach { it.setOnFocusChangeListener { _, _ -> recalc() } }
        gstSwitch.setOnCheckedChangeListener { _, _ -> recalc() }
        findViewById<Button>(R.id.addItem).setOnClickListener { addItem() }
        findViewById<Button>(R.id.saveSale).setOnClickListener { saveAndPdf() }
        renderLines(); recalc()
    }

    private fun loadMasters() {
        parties = db.allParties(); products = db.allProducts()
        partySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, parties.map { it.medicalName }.ifEmpty { listOf("— Add Medical / Party first —") })
        productSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, products.map { "${it.productName} • ${it.pack.ifBlank { "" }} • ${it.batch.ifBlank { "No batch" }}" }.ifEmpty { listOf("— Add Product first —") })
        if (parties.isEmpty()) Toast.makeText(this, "Party Master मध्ये Medical add करा", Toast.LENGTH_LONG).show()
        if (products.isEmpty()) Toast.makeText(this, "Product Master मध्ये Product add करा", Toast.LENGTH_LONG).show()
    }

    private fun addItem() {
        val p = products.getOrNull(productSpinner.selectedItemPosition)
        if (p == null) { Toast.makeText(this, "Product Master मध्ये product add करा", Toast.LENGTH_SHORT).show(); return }
        val q = qty.text.toString().toDoubleOrNull() ?: 0.0
        val r = rate.text.toString().toDoubleOrNull() ?: 0.0
        val d = discount.text.toString().toDoubleOrNull() ?: 0.0
        if (q <= 0 || r < 0 || d < 0 || d > 100) { Toast.makeText(this, "Qty / Rate / Discount तपासा", Toast.LENGTH_SHORT).show(); return }
        if (q > p.openingStock && p.openingStock > 0) { Toast.makeText(this, "Available stock: ${money(p.openingStock)}", Toast.LENGTH_SHORT).show(); return }
        lines.add(SaleLine(p, q, r, d, gstSwitch.isChecked)); renderLines(); recalc()
        qty.setText("1"); discount.setText("0")
    }

    private fun renderLines() {
        itemsContainer.removeAllViews()
        if (lines.isEmpty()) {
            TextView(this).apply { text = "No items added yet"; setTextColor(0xFFBDB6C8.toInt()); setPadding(0, 8, 0, 8); itemsContainer.addView(this) }
            return
        }
        lines.forEachIndexed { index, line ->
            val t = TextView(this).apply {
                text = "${index + 1}. ${line.product.productName}  |  ${money(line.qty)} × ₹${money(line.rate)}\nBatch ${line.product.batch.ifBlank { "-" }} • Exp ${line.product.expiry.ifBlank { "-" }} • Disc ${money(line.discount)}% • GST ${money(line.gstPercent)}%\nAmount: ₹${money(line.total)}"
                setTextColor(0xFFFFFFFF.toInt()); textSize = 14f; setPadding(10, 10, 10, 10); setBackgroundColor(0xFF211D26.toInt())
                setOnLongClickListener { lines.removeAt(index); renderLines(); recalc(); true }
            }
            itemsContainer.addView(t, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 4, 0, 4) })
        }
    }

    private fun recalc() {
        val q = qty.text.toString().toDoubleOrNull() ?: 0.0; val r = rate.text.toString().toDoubleOrNull() ?: 0.0; val d = discount.text.toString().toDoubleOrNull() ?: 0.0
        val p = products.getOrNull(productSpinner.selectedItemPosition)
        val draft = if (p != null && q > 0 && r >= 0) SaleLine(p, q, r, d.coerceIn(0.0, 100.0), gstSwitch.isChecked) else null
        val gst = lines.sumOf { it.gstAmount } + (draft?.gstAmount ?: 0.0)
        val total = lines.sumOf { it.total } + (draft?.total ?: 0.0)
        gstView.text = "GST: ₹${money(gst)}"; totalView.text = "Grand Total: ₹${money(total)}"
    }

    private fun saveAndPdf() {
        val party = parties.getOrNull(partySpinner.selectedItemPosition)
        if (party == null) { Toast.makeText(this, "Medical / Party select करा", Toast.LENGTH_SHORT).show(); return }
        if (lines.isEmpty()) { Toast.makeText(this, "किमान 1 item ADD करा", Toast.LENGTH_SHORT).show(); return }
        lines.forEach { line -> db.saveSale(invoiceNo, invoiceDate, party.id, line.product.id, line.product.batch, line.product.expiry, line.qty, line.rate, line.discount, line.gstEnabled, line.gstPercent, round2(line.taxable), round2(line.gstAmount), round2(line.total))
            db.reduceProductStock(line.product.id, line.qty)
        }
        val file = createPdf(party)
        Toast.makeText(this, "Sale saved • $invoiceNo", Toast.LENGTH_LONG).show()
        openPdf(file)
    }

    private fun createPdf(party: Party): File {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(842, 595, 1).create())
        val c = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF111111.toInt()
            typeface = Typeface.create("sans", Typeface.NORMAL)
        }
        fun text(s: String, x: Float, y: Float, size: Float = 9f, bold: Boolean = false) {
            paint.style = Paint.Style.FILL
            paint.textSize = size
            paint.typeface = Typeface.create("sans", if (bold) Typeface.BOLD else Typeface.NORMAL)
            c.drawText(s, x, y, paint)
        }
        fun line(x1: Float, y1: Float, x2: Float, y2: Float, width: Float = 1f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = width
            c.drawLine(x1, y1, x2, y2, paint)
            paint.style = Paint.Style.FILL
        }
        fun box(l: Float, t: Float, r: Float, b: Float, width: Float = 1f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = width
            c.drawRect(l, t, r, b, paint)
            paint.style = Paint.Style.FILL
        }
        fun fit(s: String, max: Int) = if (s.length <= max) s else s.take(max - 1) + "…"

        // Outer border and header
        box(18f, 18f, 824f, 577f, 1.5f)
        text("RATNASHREE PHARMA", 32f, 42f, 20f, true)
        text("MEDICAL DISTRIBUTION", 33f, 58f, 9f, true)
        text("Medical Distribution & Pharmaceutical Supplies", 33f, 72f, 8f)
        text("TAX INVOICE", 694f, 42f, 14f, true)
        text("Invoice No.: $invoiceNo", 612f, 58f, 9f, true)
        text("Date: $invoiceDate", 688f, 72f, 9f)
        line(25f, 82f, 817f, 82f, 1.2f)

        // Party block
        text("BILL TO", 32f, 98f, 8f, true)
        text(fit(party.medicalName, 42), 32f, 114f, 12f, true)
        text("Owner/Contact: ${fit(party.ownerName.ifBlank { "-" }, 34)}", 32f, 129f, 8.5f)
        text("Mobile: ${party.mobile.ifBlank { "-" }}", 32f, 143f, 8.5f)
        text("Address: ${fit(party.address.ifBlank { "-" }, 55)}", 32f, 157f, 8.5f)
        text("GSTIN: ${party.gstin.ifBlank { "-" }}", 430f, 114f, 8.5f)
        text("State: ${party.state.ifBlank { "-" }}   Code: ${party.stateCode.ifBlank { "-" }}", 430f, 129f, 8.5f)
        text("Drug Licence 1: ${party.drugLicense1.ifBlank { "-" }}", 430f, 143f, 8.5f)
        text("Drug Licence 2: ${party.drugLicense2.ifBlank { "-" }}", 430f, 157f, 8.5f)
        line(25f, 166f, 817f, 166f, 1f)

        // Item table
        val top = 174f
        val bottom = 404f
        box(25f, top, 817f, bottom, 1f)
        val xs = floatArrayOf(25f, 220f, 286f, 340f, 386f, 430f, 500f, 556f, 615f, 684f, 817f)
        for (x in xs.drop(1).dropLast(1)) line(x, top, x, bottom, 0.7f)
        line(25f, 198f, 817f, 198f, 1f)
        text("#", 31f, 190f, 8f, true)
        text("Product / Pack", 44f, 190f, 8f, true)
        text("Batch", 226f, 190f, 8f, true)
        text("Expiry", 291f, 190f, 8f, true)
        text("HSN", 345f, 190f, 8f, true)
        text("Qty", 394f, 190f, 8f, true)
        text("Rate", 438f, 190f, 8f, true)
        text("Disc %", 505f, 190f, 8f, true)
        text("GST %", 561f, 190f, 8f, true)
        text("GST", 622f, 190f, 8f, true)
        text("Amount", 700f, 190f, 8f, true)

        var y = 216f
        lines.take(10).forEachIndexed { i, l ->
            text("${i + 1}", 31f, y, 8f)
            text(fit("${l.product.productName}${if (l.product.pack.isNotBlank()) " / ${l.product.pack}" else ""}", 28), 44f, y, 8f)
            text(fit(l.product.batch.ifBlank { "-" }, 11), 226f, y, 8f)
            text(fit(l.product.expiry.ifBlank { "-" }, 9), 291f, y, 8f)
            text(fit(l.product.hsn.ifBlank { "-" }, 8), 345f, y, 8f)
            text(money(l.qty), 394f, y, 8f)
            text(money(l.rate), 438f, y, 8f)
            text("${money(l.discount)}%", 505f, y, 8f)
            text("${money(l.gstPercent)}%", 561f, y, 8f)
            text(money(l.gstAmount), 622f, y, 8f)
            text(money(l.total), 700f, y, 8f)
            y += 20f
            if (i < 9) line(25f, y - 9f, 817f, y - 9f, 0.35f)
        }
        if (lines.size > 10) text("+ ${lines.size - 10} more item(s) on next bill page", 44f, bottom - 8f, 8f, true)

        // Totals and notes
        val subtotal = lines.sumOf { it.gross }
        val disc = lines.sumOf { it.discountAmount }
        val taxable = lines.sumOf { it.taxable }
        val gst = lines.sumOf { it.gstAmount }
        val total = lines.sumOf { it.total }
        val totalsTop = 416f
        box(560f, totalsTop, 817f, 522f, 1f)
        text("Subtotal", 575f, 434f, 8.5f)
        text("₹${money(subtotal)}", 745f, 434f, 8.5f)
        text("Discount", 575f, 450f, 8.5f)
        text("₹${money(disc)}", 745f, 450f, 8.5f)
        text("Taxable Value", 575f, 466f, 8.5f)
        text("₹${money(taxable)}", 745f, 466f, 8.5f)
        text("GST", 575f, 482f, 8.5f)
        text("₹${money(gst)}", 745f, 482f, 8.5f)
        line(568f, 489f, 809f, 489f, 0.8f)
        text("GRAND TOTAL", 575f, 508f, 11f, true)
        text("₹${money(total)}", 730f, 508f, 12f, true)

        text("Amount in Words", 32f, 434f, 8.5f, true)
        text(fit(amountWords(total), 70), 32f, 449f, 8.5f)
        text("Payment Terms", 32f, 472f, 8.5f, true)
        text("Subject to Ratnashree Pharma sale terms. Goods once sold are subject to applicable policy.", 32f, 487f, 8f)
        text("This is a computer-generated invoice.", 32f, 503f, 8f)

        // Signature block
        text("For RATNASHREE PHARMA", 670f, 545f, 8.5f, true)
        line(690f, 554f, 805f, 554f, 0.8f)
        text("Authorized Signature / Stamp", 685f, 568f, 8f)

        doc.finishPage(page)
        val dir = File(getExternalFilesDir("Documents"), "RatnashreeBills")
        dir.mkdirs()
        val file = File(dir, "$invoiceNo.pdf")
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        return file
    }

    private fun openPdf(file: File) { try { val uri: Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file); startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, "application/pdf"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }) } catch (_: Exception) { Toast.makeText(this, "PDF तयार: ${file.name}", Toast.LENGTH_LONG).show() } }

    private fun amountWords(v: Double): String {
        val n = v.toLong()
        if (n == 0L) return "Rupees Zero Only"
        fun under1000(x: Int): String {
            val ones = arrayOf("", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen")
            val tens = arrayOf("", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety")
            return when {
                x < 20 -> ones[x]
                x < 100 -> tens[x / 10] + if (x % 10 != 0) " " + ones[x % 10] else ""
                else -> ones[x / 100] + " Hundred" + if (x % 100 != 0) " " + under1000(x % 100) else ""
            }
        }
        var r = n
        val crore = r / 10000000; r %= 10000000
        val lakh = r / 100000; r %= 100000
        val thousand = r / 1000; r %= 1000
        val parts = mutableListOf<String>()
        if (crore > 0) parts.add(under1000(crore.toInt()) + " Crore")
        if (lakh > 0) parts.add(under1000(lakh.toInt()) + " Lakh")
        if (thousand > 0) parts.add(under1000(thousand.toInt()) + " Thousand")
        if (r > 0) parts.add(under1000(r.toInt()))
        return "Rupees ${parts.joinToString(" ")} Only"
    }
    private fun round2(v: Double) = round(v * 100.0) / 100.0
    private fun money(v: Double) = String.format(Locale.US, "%.2f", v)
}
