plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.ratnashree.pharma"; compileSdk=35
    defaultConfig { applicationId="com.ratnashree.pharma"; minSdk=24; targetSdk=35; versionCode=5; versionName="1.5" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
