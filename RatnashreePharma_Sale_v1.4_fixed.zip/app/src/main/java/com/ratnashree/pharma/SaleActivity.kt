package com.ratnashree.pharma

import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.round

data class SaleLine(val product: Product, val qty: Double, val rate: Double, val discount: Double, val gstEnabled: Boolean) {
    val gross get() = qty * rate
    val discountAmount get() = gross * discount / 100.0
    val taxable get() = gross - discountAmount
    val gstPercent get() = if (gstEnabled) product.gstPercent else 0.0
    val gstAmount get() = taxable * gstPercent / 100.0
    val total get() = taxable + gstAmount
}

class SaleActivity : AppCompatActivity() {
    private lateinit var db: PartyDbHelper
    private lateinit var partySpinner: Spinner
    private lateinit var productSpinner: Spinner
    private lateinit var qty: EditText
    private lateinit var rate: EditText
    private lateinit var discount: EditText
    private lateinit var gstSwitch: Switch
    private lateinit var totalView: TextView
    private lateinit var gstView: TextView
    private lateinit var itemsContainer: LinearLayout
    private lateinit var partyInfo: TextView
    private lateinit var productInfo: TextView
    private var parties = listOf<Party>()
    private var products = listOf<Product>()
    private val lines = mutableListOf<SaleLine>()
    private val invoiceNo = "RP-${SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())}"
    private val invoiceDate = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = PartyDbHelper(this)
        setContentView(R.layout.activity_sale)
        partySpinner = findViewById(R.id.partySpinner); productSpinner = findViewById(R.id.productSpinner)
        qty = findViewById(R.id.saleQty); rate = findViewById(R.id.saleRate); discount = findViewById(R.id.saleDiscount)
        gstSwitch = findViewById(R.id.gstSwitch); totalView = findViewById(R.id.saleTotal); gstView = findViewById(R.id.saleGst)
        itemsContainer = findViewById(R.id.itemsContainer); partyInfo = findViewById(R.id.partyInfo); productInfo = findViewById(R.id.productInfo)
        findViewById<TextView>(R.id.invoiceInfo).text = "Invoice No: $invoiceNo   •   Date: $invoiceDate"
        loadMasters()
        partySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val p = parties.getOrNull(position)
                partyInfo.text = if (p == null) "No Medical added. Add one in Party Master." else "${p.ownerName.ifBlank { "Owner not set" }} • ${p.mobile.ifBlank { "Mobile not set" }}\nGSTIN: ${p.gstin.ifBlank { "Not set" }} • State Code: ${p.stateCode.ifBlank { "Not set" }}"
            }
        }
        productSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                products.getOrNull(position)?.let { p ->
                    rate.setText(if (p.saleRate > 0) money(p.saleRate) else "")
                    discount.setText(money(p.discountPercent))
                    productInfo.text = "Batch: ${p.batch.ifBlank { "-" }} • Exp: ${p.expiry.ifBlank { "-" }} • GST: ${money(p.gstPercent)}% • Stock: ${money(p.openingStock)}"
                    recalc()
                }
            }
        }
        listOf(qty, rate, discount).forEach { it.setOnFocusChangeListener { _, _ -> recalc() } }
        gstSwitch.setOnCheckedChangeListener { _, _ -> recalc() }
        findViewById<Button>(R.id.addItem).setOnClickListener { addItem() }
        findViewById<Button>(R.id.saveSale).setOnClickListener { saveAndPdf() }
        renderLines(); recalc()
    }

    private fun loadMasters() {
        parties = db.allParties(); products = db.allProducts()
        partySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, parties.map { it.medicalName }.ifEmpty { listOf("— Add Medical / Party first —") })
        productSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, products.map { "${it.productName} • ${it.pack.ifBlank { "" }} • ${it.batch.ifBlank { "No batch" }}" }.ifEmpty { listOf("— Add Product first —") })
        if (parties.isEmpty()) Toast.makeText(this, "Party Master मध्ये Medical add करा", Toast.LENGTH_LONG).show()
        if (products.isEmpty()) Toast.makeText(this, "Product Master मध्ये Product add करा", Toast.LENGTH_LONG).show()
    }

    private fun addItem() {
        val p = products.getOrNull(productSpinner.selectedItemPosition)
        if (p == null) { Toast.makeText(this, "Product Master मध्ये product add करा", Toast.LENGTH_SHORT).show(); return }
        val q = qty.text.toString().toDoubleOrNull() ?: 0.0
        val r = rate.text.toString().toDoubleOrNull() ?: 0.0
        val d = discount.text.toString().toDoubleOrNull() ?: 0.0
        if (q <= 0 || r < 0 || d < 0 || d > 100) { Toast.makeText(this, "Qty / Rate / Discount तपासा", Toast.LENGTH_SHORT).show(); return }
        if (q > p.openingStock && p.openingStock > 0) { Toast.makeText(this, "Available stock: ${money(p.openingStock)}", Toast.LENGTH_SHORT).show(); return }
        lines.add(SaleLine(p, q, r, d, gstSwitch.isChecked)); renderLines(); recalc()
        qty.setText("1"); discount.setText("0")
    }

    private fun renderLines() {
        itemsContainer.removeAllViews()
        if (lines.isEmpty()) {
            TextView(this).apply { text = "No items added yet"; setTextColor(0xFFBDB6C8.toInt()); setPadding(0, 8, 0, 8); itemsContainer.addView(this) }
            return
        }
        lines.forEachIndexed { index, line ->
            val t = TextView(this).apply {
                text = "${index + 1}. ${line.product.productName}  |  ${money(line.qty)} × ₹${money(line.rate)}\nBatch ${line.product.batch.ifBlank { "-" }} • Exp ${line.product.expiry.ifBlank { "-" }} • Disc ${money(line.discount)}% • GST ${money(line.gstPercent)}%\nAmount: ₹${money(line.total)}"
                setTextColor(0xFFFFFFFF.toInt()); textSize = 14f; setPadding(10, 10, 10, 10); setBackgroundColor(0xFF211D26.toInt())
                setOnLongClickListener { lines.removeAt(index); renderLines(); recalc(); true }
            }
            itemsContainer.addView(t, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 4, 0, 4) })
        }
    }

    private fun recalc() {
        val q = qty.text.toString().toDoubleOrNull() ?: 0.0; val r = rate.text.toString().toDoubleOrNull() ?: 0.0; val d = discount.text.toString().toDoubleOrNull() ?: 0.0
        val p = products.getOrNull(productSpinner.selectedItemPosition)
        val draft = if (p != null && q > 0 && r >= 0) SaleLine(p, q, r, d.coerceIn(0.0, 100.0), gstSwitch.isChecked) else null
        val gst = lines.sumOf { it.gstAmount } + (draft?.gstAmount ?: 0.0)
        val total = lines.sumOf { it.total } + (draft?.total ?: 0.0)
        gstView.text = "GST: ₹${money(gst)}"; totalView.text = "Grand Total: ₹${money(total)}"
    }

    private fun saveAndPdf() {
        val party = parties.getOrNull(partySpinner.selectedItemPosition)
        if (party == null) { Toast.makeText(this, "Medical / Party select करा", Toast.LENGTH_SHORT).show(); return }
        if (lines.isEmpty()) { Toast.makeText(this, "किमान 1 item ADD करा", Toast.LENGTH_SHORT).show(); return }
        lines.forEach { line -> db.saveSale(invoiceNo, invoiceDate, party.id, line.product.id, line.product.batch, line.product.expiry, line.qty, line.rate, line.discount, line.gstEnabled, line.gstPercent, round2(line.taxable), round2(line.gstAmount), round2(line.total))
            db.reduceProductStock(line.product.id, line.qty)
        }
        val file = createPdf(party)
        Toast.makeText(this, "Sale saved • $invoiceNo", Toast.LENGTH_LONG).show()
        openPdf(file)
    }

    private fun createPdf(party: Party): File {
        val doc = PdfDocument(); val page = doc.startPage(PdfDocument.PageInfo.Builder(842, 595, 1).create()); val c = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG); paint.typeface = Typeface.create("sans", Typeface.NORMAL); paint.textSize = 10f
        fun text(s: String, x: Float, y: Float, size: Float = 10f, bold: Boolean = false) { paint.textSize = size; paint.typeface = Typeface.create("sans", if (bold) Typeface.BOLD else Typeface.NORMAL); c.drawText(s, x, y, paint) }
        text("RATNASHREE PHARMA", 30f, 32f, 20f, true); text("MEDICAL DISTRIBUTION", 30f, 49f, 10f, true)
        text("Invoice: $invoiceNo", 610f, 30f, 11f, true); text("Date: $invoiceDate", 650f, 47f)
        text("Medical: ${party.medicalName}", 30f, 75f, 11f, true); text("Mobile: ${party.mobile}", 30f, 92f); text("GSTIN: ${party.gstin.ifBlank { "-" }}", 220f, 92f); text("State Code: ${party.stateCode.ifBlank { "-" }}", 420f, 92f)
        text("Drug Licence 1: ${party.drugLicense1.ifBlank { "-" }}", 30f, 109f); text("Drug Licence 2: ${party.drugLicense2.ifBlank { "-" }}", 260f, 109f)
        paint.style = Paint.Style.STROKE; c.drawRect(25f, 120f, 817f, 142f, paint); paint.style = Paint.Style.FILL
        text("Product", 30f, 136f, 9f, true); text("Batch", 285f, 136f, 9f, true); text("Expiry", 375f, 136f, 9f, true); text("Qty", 445f, 136f, 9f, true); text("Rate", 490f, 136f, 9f, true); text("Disc", 555f, 136f, 9f, true); text("GST", 615f, 136f, 9f, true); text("Amount", 700f, 136f, 9f, true)
        var y = 162f
        lines.take(16).forEach { l -> text(l.product.productName.take(36), 30f, y); text(l.product.batch.take(12), 285f, y); text(l.product.expiry.take(10), 375f, y); text(money(l.qty), 445f, y); text(money(l.rate), 490f, y); text("${money(l.discount)}%", 555f, y); text("${money(l.gstPercent)}%", 615f, y); text(money(l.total), 700f, y); y += 22f }
        paint.style = Paint.Style.STROKE; c.drawLine(25f, y - 10f, 817f, y - 10f, paint); paint.style = Paint.Style.FILL
        val subtotal = lines.sumOf { it.gross }; val disc = lines.sumOf { it.discountAmount }; val taxable = lines.sumOf { it.taxable }; val gst = lines.sumOf { it.gstAmount }; val total = lines.sumOf { it.total }
        text("Subtotal: ₹${money(subtotal)}", 585f, y + 15f); text("Discount: ₹${money(disc)}", 585f, y + 33f); text("Taxable: ₹${money(taxable)}", 585f, y + 51f); text("GST: ₹${money(gst)}", 585f, y + 69f); text("GRAND TOTAL: ₹${money(total)}", 585f, y + 92f, 14f, true)
        text("Amount in Words: ${amountWords(total)}", 30f, 385f, 10f, true); text("Terms: Subject to Ratnashree Pharma sale terms.", 30f, 410f)
        text("Authorized Signature", 690f, 510f, 10f, true); text("RATNASHREE PHARMA", 665f, 530f, 11f, true)
        doc.finishPage(page); val dir = File(getExternalFilesDir("Documents"), "RatnashreeBills"); dir.mkdirs(); val file = File(dir, "$invoiceNo.pdf"); file.outputStream().use { doc.writeTo(it) }; doc.close(); return file
    }

    private fun openPdf(file: File) { try { val uri: Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file); startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, "application/pdf"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }) } catch (_: Exception) { Toast.makeText(this, "PDF तयार: ${file.name}", Toast.LENGTH_LONG).show() } }

    private fun amountWords(v: Double): String { val rupees = v.toLong(); return "Rupees ${rupees.toString().reversed().chunked(3).joinToString(",").reversed()} Only" }
    private fun round2(v: Double) = round(v * 100.0) / 100.0
    private fun money(v: Double) = String.format(Locale.US, "%.2f", v)
}
